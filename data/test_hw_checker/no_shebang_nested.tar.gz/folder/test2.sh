run the program
