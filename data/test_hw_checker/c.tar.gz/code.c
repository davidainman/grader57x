here's some c code
