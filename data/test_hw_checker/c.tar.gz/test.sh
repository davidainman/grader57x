#!/bin/sh
run the program
