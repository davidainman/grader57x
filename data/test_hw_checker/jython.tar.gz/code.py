Python code for jython
