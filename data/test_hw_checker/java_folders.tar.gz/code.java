Java code
