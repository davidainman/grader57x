C++ code
